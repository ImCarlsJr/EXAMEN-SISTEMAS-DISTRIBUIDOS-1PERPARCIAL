# Análisis de Rendimiento — Parte 1

## Resultados de ejecución

- Hilos: 1.504 segundos
- Procesos: 1.700 segundos
- Tareas completadas: 20

## Interpretación

Los hilos fueron más rápidos en esta simulación, ya que las tareas son I/O bound (simulan tiempo de espera con `sleep`). En este tipo de tareas, el uso de hilos permite mayor eficiencia porque pueden ejecutarse concurrentemente sin bloquear la CPU.

Por otro lado, los procesos implican mayor sobrecarga de creación y comunicación, pero serían preferibles en tareas CPU bound (por ejemplo, cálculos matemáticos intensivos).

## Conclusión

- **Mejor usar hilos para tareas con esperas o entrada/salida.**
- **Mejor usar procesos para tareas pesadas de CPU.**

## Conceptos aplicados

- Locks para sincronización y evitar condiciones de carrera.
- Memoria compartida con `multiprocessing.Value`.
- Comparación de rendimiento entre concurrencia con hilos y paralelismo con procesos.
