# task_processor.py
import multiprocessing
import threading
import time
import random
from dataclasses import dataclass

@dataclass
class Task:
    id: int
    difficulty: int  # 1..5

class TaskProcessor:
    def __init__(self):
        # contador para procesos (compartido entre procesos)
        self.tasks_completed_process = multiprocessing.Value('i', 0)
        # para sincronizar acceso desde procesos (usaremos get_lock)
        # contador para hilos
        self.tasks_completed_threads = 0
        self.thread_lock = threading.Lock()

    def process_task(self, task_id, difficulty, is_process=False):
        """
        Simula procesamiento con diferente dificultad
        difficulty: 1 (fácil) a 5 (difícil)
        Según tu pista: tiempo = difficulty * 0.3 segundos
        """
        print(f"Iniciando tarea {task_id} (dificultad: {difficulty})")
        processing_time = difficulty * 0.3
        time.sleep(processing_time)  # simula trabajo
        result = task_id * difficulty
        print(f"Tarea {task_id} completada - Resultado: {result}")
        return result

    # ---------------- HILOS ----------------
    def _worker_thread(self, task: Task):
        # Ejecuta la tarea (I/O-bound simulada con sleep)
        self.process_task(task.id, task.difficulty, is_process=False)
        # actualizar contador con lock para evitar condición de carrera
        with self.thread_lock:
            self.tasks_completed_threads += 1

    def run_with_threads(self, tasks):
        self.tasks_completed_threads = 0
        threads = []
        start = time.perf_counter()
        for t in tasks:
            thread = threading.Thread(target=self._worker_thread, args=(t,))
            thread.start()
            threads.append(thread)
        for thread in threads:
            thread.join()
        end = time.perf_counter()
        elapsed = end - start
        return elapsed, self.tasks_completed_threads

    # ---------------- PROCESOS ----------------
    @staticmethod
    def _worker_process(task_id, difficulty, shared_counter):
        # worker que corre en otro proceso
        # simulamos el mismo trabajo
        print(f"[proc {multiprocessing.current_process().pid}] Iniciando tarea {task_id} (dificultad: {difficulty})")
        time.sleep(difficulty * 0.3)
        result = task_id * difficulty
        print(f"[proc {multiprocessing.current_process().pid}] Tarea {task_id} completada - Resultado: {result}")
        # actualizar contador usando el lock del Value
        with shared_counter.get_lock():
            shared_counter.value += 1

    def run_with_processes(self, tasks):
        # reset contador
        with self.tasks_completed_process.get_lock():
            self.tasks_completed_process.value = 0

        processes = []
        start = time.perf_counter()
        for t in tasks:
            p = multiprocessing.Process(
                target=TaskProcessor._worker_process,
                args=(t.id, t.difficulty, self.tasks_completed_process)
            )
            p.start()
            processes.append(p)
        for p in processes:
            p.join()
        end = time.perf_counter()
        elapsed = end - start
        return elapsed, self.tasks_completed_process.value

# ---------------- Helpers / ejecución ----------------
def generate_tasks(n=20, seed=None):
    if seed is not None:
        random.seed(seed)
    tasks = []
    for i in range(1, n+1):
        difficulty = random.randint(1, 5)
        tasks.append(Task(id=i, difficulty=difficulty))
    return tasks

def main():
    print("Generando 20 tareas (dificultad 1-5)...")
    tasks = generate_tasks(20, seed=42)  # seed para reproducibilidad
    for t in tasks:
        print(f"Task {t.id}: difficulty={t.difficulty}")

    tp = TaskProcessor()

    print("\n=== Ejecutando con HILOS ===")
    t_thread, completed_thread = tp.run_with_threads(tasks)
    print(f"Hilos: tiempo {t_thread:.3f}s - tareas completadas: {completed_thread}")

    print("\n=== Ejecutando con PROCESOS ===")
    t_proc, completed_proc = tp.run_with_processes(tasks)
    print(f"Procesos: tiempo {t_proc:.3f}s - tareas completadas: {completed_proc}")

    # Análisis rápido
    print("\n--- Análisis rápido ---")
    if t_proc < t_thread:
        print("Procesos fueron más rápidos en esta prueba.")
    elif t_proc > t_thread:
        print("Hilos fueron más rápidos en esta prueba.")
    else:
        print("Tiempos iguales (raro).")

if __name__ == "__main__":
    main()
