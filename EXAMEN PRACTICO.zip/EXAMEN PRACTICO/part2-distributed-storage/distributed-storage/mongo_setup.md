# Configuración MongoDB en Docker (2 nodos)

1. Levantar contenedores:
   docker-compose up -d

2. Verificar que ambos corren:
   docker ps
   # mongo1 (host:27017) y mongo2 (host:27018 -> dentro 27017)

3. Mostrar estadísticas desde Python:
   pip install -r requirements.txt
   python part2-distributed-storage/storage_system.py

Notas:
- La distribución de documentos es por hashing del _id.
- Búsqueda distribuida: el método find_document consulta cada nodo hasta encontrar el documento.
- En producción se usaría un clúster replica set / sharding, pero aquí demostramos la lógica de distribución y búsqueda.
