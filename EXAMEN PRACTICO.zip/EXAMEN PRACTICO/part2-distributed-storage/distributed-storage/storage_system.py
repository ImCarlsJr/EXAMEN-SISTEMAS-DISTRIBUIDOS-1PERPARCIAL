# storage_system.py
from pymongo import MongoClient
from datetime import datetime
import hashlib
import random
import time

class DistributedStorage:
    def __init__(self, uri1='mongodb://localhost:27017', uri2='mongodb://localhost:27018', db_name='distributed_db', coll_name='documents'):
        # Conexión a ambos nodos según tu pista
        self.client1 = MongoClient(uri1, serverSelectionTimeoutMS=5000)
        self.client2 = MongoClient(uri2, serverSelectionTimeoutMS=5000)
        self.db1 = self.client1[db_name]
        self.db2 = self.client2[db_name]
        self.coll1 = self.db1[coll_name]
        self.coll2 = self.db2[coll_name]

    def _select_node_for_document(self, document_data):
        """
        Usa hashing MD5 sobre el id (o sobre 'id' generado) para elegir nodo.
        Retorna (collection, node_name).
        """
        # Obtener ID base (si no tiene, usar timestamp+random para un string único)
        document_id = str(document_data.get('id', f"{datetime.utcnow().isoformat()}-{random.randint(0,1_000_000)}"))
        hash_value = hashlib.md5(document_id.encode('utf-8')).hexdigest()
        node_index = int(hash_value, 16) % 2  # 2 nodos
        if node_index == 0:
            return self.coll1, "node1"
        else:
            return self.coll2, "node2"

    def insert_document(self, data):
        # Seleccionar nodo automáticamente
        target_coll, node_name = self._select_node_for_document(data)
        # Preparar documento
        document = {
            '_id': data.get('id'),  # si es None, Mongo generará ObjectId
            'data': data,
            'node': node_name,
            'created_at': datetime.utcnow()
        }
        # si _id es None, eliminar para que Mongo lo genere
        if document['_id'] is None:
            document.pop('_id')
        result = target_coll.insert_one(document)
        print(f"✅ Guardado en {node_name} - inserted_id: {result.inserted_id}")
        return {'inserted_id': result.inserted_id, 'node': node_name}

    def find_document(self, document_id):
        """
        Busca documento en ambos nodos y marca la fuente.
        Retorna lista de resultados encontrados (puede ser vacía).
        """
        results = []
        print(f"🔍 Buscando documento {document_id} en node1...")
        doc1 = self.coll1.find_one({'_id': document_id})
        if doc1:
            doc1['source_node'] = 'node1'
            results.append(doc1)

        print(f"🔍 Buscando documento {document_id} en node2...")
        doc2 = self.coll2.find_one({'_id': document_id})
        if doc2:
            doc2['source_node'] = 'node2'
            results.append(doc2)

        return results

    def get_stats(self):
        """
        Cuenta documentos en cada nodo y devuelve estadísticas.
        """
        count1 = self.coll1.count_documents({})
        count2 = self.coll2.count_documents({})
        total = count1 + count2
        stats = {
            'node1': {'count': count1, 'percentage': (count1/total*100) if total>0 else 0},
            'node2': {'count': count2, 'percentage': (count2/total*100) if total>0 else 0},
            'total': total
        }
        return stats

def generate_sample_data(num_documents=100):
    sample_data = []
    for i in range(num_documents):
        sample_data.append({
            'id': i,  # id único por documento
            'name': f'Documento_{i}',
            'value': i * 10,
            'category': f'categoria_{i % 5}',
            'timestamp': datetime.utcnow()
        })
    return sample_data

def main():
    print("Conectando a nodos MongoDB...")
    ds = DistributedStorage()
    try:
        ds.client1.admin.command('ping')
        ds.client2.admin.command('ping')
        print(" Conectado a ambos nodos")
    except Exception as e:
        print(" Error de conexión:", e)
        return

    # Generar e insertar 100 documentos
    docs = generate_sample_data(100)
    start = time.perf_counter()
    for d in docs:
        ds.insert_document(d)
    end = time.perf_counter()
    print(f"Insertados 100 documentos en {end-start:.3f}s")

    # Mostrar estadísticas de distribución
    stats = ds.get_stats()
    print("Estadísticas de distribución:")
    print(f" - Nodo1: {stats['node1']['count']} documentos ({stats['node1']['percentage']:.2f}%)")
    print(f" - Nodo2: {stats['node2']['count']} documentos ({stats['node2']['percentage']:.2f}%)")
    print(f" - Total: {stats['total']}")

    # Probar búsqueda de algunos ids de ejemplo
    for test_id in [0, 42, 99]:
        print(f"\nProbando búsqueda para _id = {test_id}")
        found = ds.find_document(test_id)
        if found:
            for f in found:
                print(f" - Encontrado en {f['source_node']} (doc name: {f['data']['name']})")
        else:
            print(" - No encontrado en ningún nodo")

if __name__ == "__main__":
    main()
